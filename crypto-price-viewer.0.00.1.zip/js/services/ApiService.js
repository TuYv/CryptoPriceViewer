/**
 * @file ApiService.js
 * @description 处理与外部API的通信
 */

import { Config } from '../config.js';

/**
 * API服务类
 * 负责处理与CoinGecko API的所有通信
 */
class ApiService {
  /**
   * 获取加密货币数据
   * @param {Array<string>} coins - 要获取的币种代码数组
   * @param {string} currency - 货币单位
   * @returns {Promise<Array>} 加密货币数据数组
   * @throws {Error} 如果API请求失败
   */
  static async fetchCryptoData(coins, currency) {
    try {
      const currencyLower = currency.toLowerCase();
      const coinIds = this.getCoinsIds(coins);
      
      const apiUrl = `${Config.API_BASE_URL}/coins/markets?vs_currency=${currencyLower}&ids=${coinIds}&order=market_cap_desc&per_page=100&page=1&sparkline=false&price_change_percentage=24h`;
      
      const response = await fetch(apiUrl);
      
      if (!response.ok) {
        throw new Error('API请求失败');
      }
      
      return await response.json();
    } catch (error) {
      throw error;
    }
  }
  
  /**
   * 将币种代码转换为CoinGecko API的ID
   * @param {Array<string>} coins - 币种代码数组
   * @returns {string} 逗号分隔的币种ID字符串
   * @private
   */
  static getCoinsIds(coins) {
    return coins.map(coin => Config.COIN_GECKO_IDS[coin] || coin.toLowerCase()).join(',');
  }
}

// 导出API服务类
export default ApiService;