/**
 * @file SettingsManager.js
 * @description 管理应用程序设置的存储和检索
 */

import { Config } from '../config.js';

/**
 * 设置管理器类
 * 负责处理应用程序设置的存储和检索
 */
class SettingsManager {
  /**
   * 当前设置
   * @type {Object}
   * @private
   */
  static _currentSettings = {};

  /**
   * 获取当前设置
   * @returns {Object} 当前设置对象
   */
  static get currentSettings() {
    return this._currentSettings;
  }

  /**
   * 加载设置
   * @returns {Promise<Object>} 设置对象
   */
  static async loadSettings() {
    return new Promise((resolve) => {
      chrome.storage.sync.get(Config.STORAGE_KEY, (result) => {
        if (result[Config.STORAGE_KEY]) {
          this._currentSettings = result[Config.STORAGE_KEY];
        } else {
          this._currentSettings = Config.DEFAULT_SETTINGS;
          this.saveSettings();
        }
        resolve(this._currentSettings);
      });
    });
  }

  /**
   * 保存设置
   */
  static saveSettings() {
    const data = {};
    data[Config.STORAGE_KEY] = this._currentSettings;
    chrome.storage.sync.set(data);
  }

  /**
   * 更新设置
   * @param {Object} newSettings - 新的设置对象
   */
  static updateSettings(newSettings) {
    this._currentSettings = { ...this._currentSettings, ...newSettings };
    this.saveSettings();
  }
}

// 导出设置管理器类
export default SettingsManager;